Welcome to GuiceyFruit
=============================================================================== 

GuiceyFruit provides a number of utilities for working with Guice
such as support for JSR250, EJB3, JNDI, Spring and Testing utilities.


Getting Started
=============================================================================== 

To help you get started, try the following links:-

Getting Started
  http://code.google.com/p/guiceyfruit/

Annotations Supported
  http://code.google.com/p/guiceyfruit/wiki/Annotations

Using Maven
  http://code.google.com/p/guiceyfruit/wiki/Maven

Spring support
  http://code.google.com/p/guiceyfruit/wiki/Spring

Lifecycle
  http://code.google.com/p/guiceyfruit/wiki/Lifecycle

JNDI
  http://code.google.com/p/guiceyfruit/wiki/JNDI

Testing
  http://code.google.com/p/guiceyfruit/wiki/Testing


We welcome contributions of all kinds! Please refer to the website for details
of finding the issue tracker and google group.

If you hit any problems please talk to us on the discussion group
  http://groups.google.com/group/guiceyfruit

Enjoy!


Licensing
=============================================================================== 

This software is licensed under the terms you may find in the file
named "LICENSE.txt" in this directory.
   
