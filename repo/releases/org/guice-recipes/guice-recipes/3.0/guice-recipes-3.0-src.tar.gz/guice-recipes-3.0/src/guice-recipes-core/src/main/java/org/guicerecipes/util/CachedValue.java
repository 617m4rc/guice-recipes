package org.guicerecipes.util;

public interface CachedValue {
	Object getCachedValue();
}
